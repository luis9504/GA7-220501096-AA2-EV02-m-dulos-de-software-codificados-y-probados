# Servlet
Ejemplo de un servlet con un formulario.

## Requisitos
* JDK 11 o superior.
* Tomcat 9 ó superior.